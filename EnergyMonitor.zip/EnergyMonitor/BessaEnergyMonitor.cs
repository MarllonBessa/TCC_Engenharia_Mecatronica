﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;


namespace EnergyMonitor
{ 
    public partial class BessaEnergyMonitor : Form
    {
        //Definindo as variáveis do projeto
        float Xtime;
        float amostragem = 2;
        float Irms1 = 0;
        float Irms2 = 0;
        float Tensao1 = 0;
        float Tensao2 = 0;
        double Potencia1 = 0;
        double Potencia2 = 0;
        double Consumo1 = 0;
        double Consumo2 = 0;
        double Consumo1_anterior = 0;
        double Consumo2_anterior = 0;
        double TotalKWH = 0;
        double Demanda = 0;
        double Demanda_anterior = 0;
        string adress_slave = "9"; 
        string tensao = "0000";
        string irms = "0000";
        string str2_anterior = "0";
        string adress_slave_anterior ="0";
        string irms_anterior="0";
        string tensao_anterior="0";
        int fase_rede=1;
        int aux_fase = 0;

        String sURL = ""; //Endereço de IP do dispositivo mestre
        public BessaEnergyMonitor()
        {
            InitializeComponent();
        }
        public void ligaNoEsp()//Iniciando a troca de dados
        {
            sURL = textBox1.Text;
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(@sURL + "/LED=ON");
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            string content = new StreamReader(response.GetResponseStream()).ReadToEnd();
            richTextBox1.AppendText(content);
            richTextBox13.Text = "CONEXÃO REALIZADA COM SUCESSO!";
        }
        public void desligaNoEsp()//Finalizando a troca de dados
        {
            sURL = textBox1.Text;
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(@sURL + "/LED=OFF");
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            string content = new StreamReader(response.GetResponseStream()).ReadToEnd();
            richTextBox1.AppendText(content);
            richTextBox13.Text = "CONEXÃO FINALIZADA!";
        }
        public void pingaNoEsp()//Loop de atualização dos dados (Amostragem 2 segundos)
        {
            sURL = textBox1.Text;//Endereço de IP
            if (sURL != "http://192.168.1.111/")//Verificaçao do Endereço de IP
            {
                richTextBox13.Text = " A CONEXÃO FALHOU! FAVOR VERIFICAR O ENDEREÇO.";
            }
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(@sURL);
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            string content = new StreamReader(response.GetResponseStream()).ReadToEnd();
            string sTag = "IS"; //Marcador de início
            string sNext = "F"; //Marcador de fim
            int posi = content.IndexOf(sTag);
            int posiFim = content.IndexOf(sNext);

            if (posi >= 0)
            {
                //Identificando o pacote dentre outros caracteres utilizados no protocolo HTTP
                string str2 = content.Substring(posi + 5, content.Length - posi - 5);
                if (str2.IndexOf(sNext) > 0) { str2 = str2.Substring(0, str2.IndexOf(sNext)); }
                textBox2.Text = str2;

                // Checagem se o pacote é válido
                int tamanho_pacote = 0;
                tamanho_pacote = str2.Length;
                string Bit_checagem = str2.Substring(0, 1);
                string Bit_checagem2 = str2.Substring(1, 4);

                if (tamanho_pacote == 9 && (Bit_checagem == "1" || Bit_checagem == "2") && Bit_checagem2 == "0124")
                {
                    //Desmembrando o pacote de dados enviados: Sensor / Tensão / Corrente
                    adress_slave = str2.Substring(0, 1);
                    tensao = str2.Substring(1, 4);
                    irms = str2.Substring(5, 4);
                    
                    //Salvando os valor anteior para casos onde a comunicação apresentar falha e aguardar a processa amostra.
                    str2_anterior = str2;
                    adress_slave_anterior = adress_slave; 
                    tensao_anterior = tensao;
                    irms_anterior = irms;

                    //Secionando os dados por sensores
                    int Adress_num = int.Parse(adress_slave);
                    if (Adress_num == 1)
                    {
                        Irms1 = (int.Parse(irms));
                        Tensao1 = int.Parse(tensao);                    
                    }
                    if (Adress_num == 2)
                    {
                        Irms2 = (int.Parse(irms)); 
                        Tensao2 = int.Parse(tensao);
                    }
                }
                else //Salvando o valor anterior em caso de erro
                {
                    str2 = str2_anterior;
                    adress_slave = adress_slave_anterior;
                    tensao = tensao_anterior;
                    irms= irms_anterior;

                    int Adress_num = int.Parse(adress_slave_anterior);
                    if (Adress_num == 1)
                    {
                        Irms1 = int.Parse(irms_anterior);
                        Tensao1 = int.Parse(tensao_anterior);
                    }
                    if (Adress_num == 2)
                    {
                        Irms2 = int.Parse(irms_anterior);
                        Tensao2 = int.Parse(tensao_anterior);
                    }

                }
                //Convertendo o valor lido de corrente. O valor é multiplicado por 100 pelo dispotivo escravo quando transmitido
                double IrmsConv1 = Irms1 / 100.00;
                double IrmsConv2 = Irms2 / 100.00;
                double IrmsConv1Ant = IrmsConv1;
                double IrmsConv2Ant = IrmsConv2;
                if (IrmsConv1 > 100) //Valor máximo lido pelo sensor
                {
                    IrmsConv1 = IrmsConv1Ant;

                }
                if (IrmsConv2 > 100) //Valor máximo lido pelo sensor
                {
                    IrmsConv2 = IrmsConv2Ant;
                }

                //Definindo qual o tipo de rede de alimentação

                if (textBox6.Text == "MONO") {
                    fase_rede = 1;
                    if (aux_fase == 0)
                    {
                        richTextBox13.Text = "";
                        aux_fase = 1;
                    }
                }
                else if (textBox6.Text == "BI")
                {
                    fase_rede = 2;
                    if (aux_fase == 0)
                    {
                        richTextBox13.Text = "";
                        aux_fase = 1;
                    }

                }
                else if (textBox6.Text == "TRI")
                {
                    fase_rede = 3;
                    if (aux_fase == 0)
                    {
                        richTextBox13.Text = "";
                        aux_fase = 1;
                    }
                }
                else {
                    //Caso a informação da rede não seja válida, retorna uma mensagem e mantêm a rede pré-configurada
                    richTextBox13.Text = "FASE INCORRETA! A fase deve ser: MONO, BI ou TRI.";
                    aux_fase = 0;
                }

                // Calculando a demanda e o consumo de energia conforme a rede
                Potencia1 = fase_rede * IrmsConv1 * Tensao1;
                Potencia2 = fase_rede * IrmsConv2 * Tensao2;
                Demanda = Potencia1 + Potencia2;

                Consumo1 = (Potencia1 *(amostragem / 3600.00))/1000 + Consumo1_anterior;
                Consumo2 = (Potencia2 *(amostragem / 3600.00))/1000 + Consumo2_anterior;

                Consumo1_anterior = Consumo1;
                Consumo2_anterior = Consumo2;

                TotalKWH = Consumo1 + Consumo2;

                //Apresentando a demanda máxima ao cliente
                if (Demanda > Demanda_anterior)
                {
                    Demanda_anterior = Demanda;
                    textBox7.Text = (Demanda/1000).ToString("0.000");

                }
                else
                {
                    textBox7.Text = (Demanda_anterior / 1000).ToString("0.000");
                }

                //  Plotando os dados macros nos indicadores
                richTextBox5.Text = (Potencia1/1000).ToString("0.000");
                richTextBox6.Text = (Potencia2/1000).ToString("0.000");
                richTextBox2.Text = tensao;
                richTextBox9.Text = tensao;
                //Salvando os dados principais caso a troca de informação falhe no próximo ciclo
                str2_anterior = str2;
                adress_slave_anterior = adress_slave;
                tensao_anterior = tensao;
                irms_anterior = irms;

                //Colocando o endereço físico (caminho do arquivo de dados)
                string path = @"DataBaseTCC.csv";

                //Configurado o banco de dados para salvar as informações
                using (StreamWriter sw = File.AppendText(path))
                {

                    //Obtendo a hora da chegada das informações em decimais
                    string Dia = System.DateTime.Now.ToString("dd/MM/yyyy");
                    string hora_completa = System.DateTime.Now.ToString("HH:mm:ss");
                    string Hora = System.DateTime.Now.ToString("HH");
                    string Minutos = System.DateTime.Now.ToString("mm");
                    string Segundos = System.DateTime.Now.ToString("ss");
                    int hora_num = int.Parse(Hora);
                    int Minutos_num = int.Parse(Minutos);
                    int Segundos_num = int.Parse(Segundos);
                    double hora_decimal = (hora_num + Minutos_num/60.0000 + Segundos_num/3600.0000);
                    //Escrevendo as informações no arquivo de dados;
                    sw.Write(Dia);
                    sw.Write(";");
                    sw.Write(hora_decimal.ToString("N4"));
                    sw.Write(";");
                    sw.Write(Potencia1);
                    sw.Write(";");
                    sw.WriteLine(Potencia2);
                }
                richTextBox1.AppendText(content);

                //GERANDO OS GRÁFICOS DA CORRENTE IRMS INSTÂNTANEA 
                
                //Sensor 01
                Sensor1_Irms.Series[0].Points.AddXY(System.DateTime.Now.ToString("HH:mm:ss"), IrmsConv1); //Gerando dados ao longo do tempo
                Sensor1_Irms.Series[1].Points.AddXY(System.DateTime.Now.ToString("HH:mm:ss"), Potencia1);
                
                if (Sensor1_Irms.Series[0].Points.Count > 100)
                {
                    Sensor1_Irms.Series[0].Points.RemoveAt(0);
                }

                Sensor1_Irms.ChartAreas[0].AxisX.Minimum = Sensor1_Irms.Series[0].Points[0].XValue;     
                Sensor1_Irms.ChartAreas[0].AxisY.Maximum = IrmsConv1 + 5;
                Sensor1_Irms.ChartAreas[0].AxisY2.Maximum = Potencia1 + 100;
             
                //Sensor 02

                Sensor2_Irms.Series[0].Points.AddXY(System.DateTime.Now.ToString("HH:mm:ss"), IrmsConv2); //Gerando dados ao longo do tempo
                Sensor2_Irms.Series[1].Points.AddXY(System.DateTime.Now.ToString("HH:mm:ss"), Potencia2);
                if (Sensor2_Irms.Series[0].Points.Count > 100)
                {
                    Sensor2_Irms.Series[0].Points.RemoveAt(0);
                }


                Sensor2_Irms.ChartAreas[0].AxisX.Minimum = Sensor2_Irms.Series[0].Points[0].XValue;
                Sensor2_Irms.ChartAreas[0].AxisY.Maximum = IrmsConv2 + 5;
                Sensor2_Irms.ChartAreas[0].AxisY2.Maximum = Potencia2 + 100;

                //Consumo em kWh total
                KWHChart.Series[0].Points.AddXY(1, Consumo1);
                KWHChart.Series[1].Points.AddXY(2, Consumo2);
                KWHChart.Series[2].Points.AddXY(3, TotalKWH);

                //KWHChart.ChartAreas[0].AxisX.Minimum = KWHChart.Series[0].Points[0].XValue;
                KWHChart.ChartAreas[0].AxisY.Maximum = TotalKWH + 0.1;

                Xtime = Xtime + amostragem; //VETOR DE TEMPO

            }
        }

        public void lerdados()
        {
            //Busca dados da DataBase e plota conforme o dia solicitado
            //Configurando as variaveis
            string DataBusca = textBox4.Text;
            int pos = 1;
            float P1Total = 0;
            float P2Total = 0;
            double ConsumoTotalDia = 0;
            float[] H = new float[86400];
            float[] P1 = new float[86400];
            float[] P2 = new float[86400];

            //Abrindo e lendo o arquivo
            string linha = "";
            string[] linhaseparada = null;
            StreamReader reader = new StreamReader(@"C:\Users\marll\Desktop\EnergyMonitor\bin\Debug\DataBaseTCC.csv", Encoding.UTF8, true);

            while (!reader.EndOfStream)
            {
                linha = reader.ReadLine();
                if (linha == null) break;
                linhaseparada = linha.Split(';');

                if(linhaseparada[0] == DataBusca)
                {
                    //Separando o pacote de dados em vetores conforme a posição de cada informação

                    H[pos] = float.Parse(linhaseparada[1]); 

                    P1[pos] = float.Parse(linhaseparada[2]);
                    Console.WriteLine(P1[pos]);

                    P2[pos] = float.Parse(linhaseparada[3]);
                    Console.WriteLine(P2[pos]);
                    pos = pos + 1;
                }

            }
            if (pos <= 1) {
                richTextBox13.Text = "NÃO EXISTEM DADOS PARA ESSA DATA!";//Caso a data esteja vazia
            }
            else
            {
                richTextBox13.Text = "DADOS GERADOS COM SUCESSO!";//Caso ocorra tudo de forma correta
            }

            for (int contador = 0; contador < pos; contador++)//Gerando os gráficos de histórico
            {
                Potencia_Data.Series[0].Points.AddXY(H[contador], P1[contador]); 
                Potencia_Data.Series[1].Points.AddXY(H[contador], P2[contador]); 
                Potencia_Data.Series[2].Points.AddXY(H[contador], P1[contador]+P2[contador]);

                Potencia_Data.ChartAreas[0].AxisX.Minimum = Potencia_Data.Series[0].Points[0].XValue; 
                Potencia_Data.ChartAreas[0].AxisX.Maximum = 24;
                Potencia_Data.ChartAreas[0].AxisY.Maximum = 8000;

                P1Total = P1[contador] + P1Total;
                P2Total = P2[contador] + P2Total;
                if (contador > 0 && H[contador] != H[contador - 1]) {
                    double intervalo = (H[contador] - H[contador - 1]);
                    ConsumoTotalDia = ConsumoTotalDia + ((P1[contador] + P2[contador])*intervalo);      
                }
                
            }
            PotenciaPercentual.Series[0].Points.AddXY("INJEÇÃO", P1Total);
            PotenciaPercentual.Series[0].Points.AddXY("SERIGRAFIA", P2Total);
            textBox10.Text = (ConsumoTotalDia/1000).ToString("0.000");
            reader.Close();
            Array.Clear(H,0, 86400);
            Array.Clear(P1,0 ,86400);
            Array.Clear(P2,0, 86400);
        }

        //Objetos do Windows Forms
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
        }
        private void BessaEnergyMonitor_Load(object sender, EventArgs e)
        {
        }
        private void textBox2_TextChanged(object sender, EventArgs e)
        {
        }
        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {
        }
        private void button1_Click(object sender, EventArgs e)
        {
            richTextBox13.Text = "Conectando...\r\r";
            pingaNoEsp();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = "Conectando ON\r\r";
            ligaNoEsp();
            timer1.Enabled = true;
        }
        private void button3_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = "Conectando OFF|\r\r";
            desligaNoEsp();
            timer1.Enabled = false;
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            richTextBox1.Text = "";
            pingaNoEsp();

        }
        private void chart1_Click(object sender, EventArgs e)
        {

        }
        private void chart1_Click_1(object sender, EventArgs e)
        {
        }
        private void textBox3_TextChanged(object sender, EventArgs e)
        {
        }
        private void button4_Click(object sender, EventArgs e)
        {
            Close();//Fecha a aplicação
        }
        private void richTextBox2_TextChanged(object sender, EventArgs e)
        {
            
        }
        private void richTextBox3_TextChanged(object sender, EventArgs e)
        {
        }
        private void richTextBox4_TextChanged(object sender, EventArgs e)
        {
        }
        private void pictureBox3_Click(object sender, EventArgs e)
        {
        }
        private void pictureBox4_Click(object sender, EventArgs e)
        {
        }
        private void richTextBox5_TextChanged(object sender, EventArgs e)
        {
        }
        private void richTextBox6_TextChanged(object sender, EventArgs e)
        {
        }
        private void richTextBox9_TextChanged(object sender, EventArgs e)
        {
        }
        private void chart1_Click_2(object sender, EventArgs e)
        {
        }
        private void textBox5_TextChanged(object sender, EventArgs e)
        {
        }
        private void chart2_Click(object sender, EventArgs e)
        {
        }
        private void chart1_Click_3(object sender, EventArgs e)
        {

        }
        private void textBox4_TextChanged(object sender, EventArgs e)
        {
        }
        private void button5_Click(object sender, EventArgs e)
        {
            //Validando as datas informadas
            string DataBusca = textBox4.Text;
            int tamanho_Data = DataBusca.Length;

            if (tamanho_Data == 10 ) {
                int DD = int.Parse(DataBusca.Substring(0, 2));
                int MM = int.Parse(DataBusca.Substring(3, 2));
                int YY = int.Parse(DataBusca.Substring(6, 4));

                if( DD<=31 && DD>=1 && MM <=12 && MM>=1 && YY <=2022 && YY >= 1900) {
                        lerdados();
                }
                else {
                    richTextBox13.Text = "DATA INVÁLIDA! Formato aceito: dd/mm/aaaa";
                }
            }
            else {

                richTextBox13.Text = "DATA INVÁLIDA! Formato aceito: dd/mm/aaaa";
            }
            
        }
        private void richTextBox11_TextChanged(object sender, EventArgs e)
        {
        }
        private void textBox4_TextChanged_1(object sender, EventArgs e)
        {
        }
        private void richTextBox13_TextChanged(object sender, EventArgs e)
        {
        }
        private void richTextBox14_TextChanged(object sender, EventArgs e)
        {
        }
        private void textBox6_TextChanged(object sender, EventArgs e)
        {
        }
        private void textBox7_TextChanged(object sender, EventArgs e)
        {
        }
        private void richTextBox15_TextChanged(object sender, EventArgs e)
        {
        }
        private void textBox10_TextChanged(object sender, EventArgs e)
        {
        }
        private void textBox11_TextChanged(object sender, EventArgs e)
        {
        }

        private void textBox11_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {

        }
    }
}
